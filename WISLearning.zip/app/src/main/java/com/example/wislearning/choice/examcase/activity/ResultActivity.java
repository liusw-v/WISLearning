package com.example.wislearning.choice.examcase.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.wislearning.R;
import com.example.wislearning.choice.examcase.adapter.ResultGridAdapter;
import com.example.wislearning.choice.examcase.inter.OnRecyclerItemClickListener;


public class ResultActivity extends AppCompatActivity {

    private RecyclerView rvResultList;
    private Button mBtBack;
    private TextView tvRight, tvWrong;
    private TextView tvSummary;
    private boolean[] flagSelected;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_result);

        initUI();

    }

    @SuppressLint("SetTextI18n")
    private void initUI() {

        int listNum = getIntent().getIntExtra("totalNum", 0);
        boolean isSelected;
        flagSelected = getIntent().getBooleanArrayExtra("flag");

        int right = 0;
        int wrong = 0;

        assert flagSelected != null;
        for (boolean b : flagSelected) {
            isSelected = b;
            if (isSelected) {
                right++;
            } else {
                wrong++;
            }
            Log.e("ResultActivity -- flag", b + "");
        }
        tvRight = findViewById(R.id.tv_result_right);
        tvWrong = findViewById(R.id.tv_result_wrong);
        tvSummary = findViewById(R.id.tv_result_summary);

        tvRight.setText(getString(R.string.right) + right);
        tvWrong.setText(getString(R.string.wrong) + wrong);
        if (right > wrong && right < listNum) {
            tvSummary.setText("共" + listNum + "道题，回答正确：" + right
                    + "道，回答错误：" + wrong + "道。你的词汇量大概在"+( right * 100)+"左右，总体表现不错，继续加油哦！"
                    +"\n（点击题号可查看解析）");
        } else if (right < wrong && right != 0) {
            tvSummary.setText("共" + listNum + "道题，回答正确：" + right
                    + "道，回答错误：" + wrong + "道。你的词汇量大概在"+( right * 100)+"左右，稍微有点落后了，不要灰心，一定要更努力。"
                    +"\n（点击题号可查看解析）");
        } else if (right == 0) {
            //tvSummary.setText(R.string.all_wrong+"\n（点击题号可查看解析）");
            tvSummary.setText("全部回答错误，你的词汇量难以估计，你需要立刻开始学习了！\n（点击题号可查看解析）");
        } else if (right == listNum) {
            //tvSummary.setText(R.string.all_rignt+"\n（点击题号可查看解析）");
            tvSummary.setText("全部回答正确，你真棒！你的词汇量大概有2000+！\n（点击题号可查看解析）");
        }

        rvResultList =  findViewById(R.id.rv_result_list);
        mBtBack = findViewById(R.id.bt_result_back);
        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //直接返回首页 启动模式 singleTask
                Intent intent = new Intent(ResultActivity.this, TextMainActivity.class);
                startActivity(intent);
//                finish();
            }
        });

        RecyclerView.LayoutManager manager = new GridLayoutManager(this, 5);
        rvResultList.setLayoutManager(manager);

        ResultGridAdapter adapter = new ResultGridAdapter(this, listNum, flagSelected, new OnRecyclerItemClickListener() {
            @Override
            public void onItemClick(View view, int position) {
//				Toast.makeText(ResultActivity.this,"test",Toast.LENGTH_SHORT).show();
                Intent intent = new Intent();
                intent.putExtra("position", position);
                setResult(RESULT_OK, intent);
                finish();
            }
        });

        rvResultList.setAdapter(adapter);
    }

}
