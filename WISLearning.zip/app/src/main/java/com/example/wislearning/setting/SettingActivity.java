package com.example.wislearning.setting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import com.example.wislearning.MainActivity;
import com.example.wislearning.R;
import com.example.wislearning.maintain.MaintainActivity;

public class SettingActivity extends AppCompatActivity {

    private ImageView mIvMainActivityBack;
    private Button mBtLanguage;
    private Button mBtInstruction;
    private Button mBtAboutUs;
    private Button mBtMaintain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        mIvMainActivityBack = findViewById(R.id.iv_mainactivity_back);
        mBtLanguage = findViewById(R.id.bt_language);
        mBtInstruction = findViewById(R.id.bt_instruction);
        mBtAboutUs = findViewById(R.id.bt_aboutus);
        mBtMaintain = findViewById(R.id.bt_maintain);
        setListeners();
    }

    private void setListeners(){
        Onclick onclick = new Onclick();
        mIvMainActivityBack.setOnClickListener(onclick);
        mBtLanguage.setOnClickListener(onclick);
        mBtInstruction.setOnClickListener(onclick);
        mBtAboutUs.setOnClickListener(onclick);
        mBtMaintain.setOnClickListener(onclick);
    }

    private class Onclick implements View.OnClickListener{
        @Override
        public void onClick(View v) {

            Intent intent = null;

            switch (v.getId()){
                case R.id.bt_language:
                    intent = new Intent(SettingActivity.this, SettingEnActivity.class);
                    break;
                case R.id.iv_mainactivity_back:
                    intent = new Intent(SettingActivity.this, MainActivity.class);
                    break;
                case R.id.bt_instruction:
                    intent = new Intent(SettingActivity.this, InstructionActivity.class);
                    break;
                case R.id.bt_aboutus:
                    intent = new Intent(SettingActivity.this, AboutUsActivity.class);
                    break;
                case R.id.bt_maintain:
                    intent = new Intent(SettingActivity.this, MaintainActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }
}
