
package com.example.wislearning.setting;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.wislearning.R;

public class SettingEnActivity extends AppCompatActivity {
    private Button mBtLanguage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting_en);
        mBtLanguage = findViewById(R.id.bt_language_en);
        mBtLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SettingEnActivity.this, SettingActivity.class);
                startActivity(intent);
            }
        });
    }
}
