package com.example.wislearning.choice.english;


import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.wislearning.choice.LearningActivity;
import com.example.wislearning.R;
import com.iflytek.cloud.SpeechUtility;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Locale;

import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 实现单词查询
 * @author thinkdoor
 *
 * 1.界面初始化
 * 2.创建handler
 * 3.实现上网查词
 *      1.创建OkClient和Request对象
 *      2.创建Call对象
 *      3.重写Call对象的enCall方法
 *          1.获取响应数据
 *          2.封装成json对象
 *          3.转为java对象
 *          4.创建message对象包裹信息
 *          5.发送给handler
 *  4.handler获取消息进行处理
 *      1.获取对象
 *      2.获取数据
 *      3.在界面显示
 */
public class EnglishActivity extends AppCompatActivity {

    private String TAG = "EnglishActivity";
    private Button mBtspeech;
    private ImageView mIvLearningActivityBack;
    private TextToSpeech tts;

    //1.界面初始化
    EditText editText;
    TextView textView;

    //2.创建handler

    @SuppressLint("HandlerLeak")
    private Handler handler = new Handler() {
        //4.handler获取消息进行处理
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            //1.获取对象
            Word word = (Word) msg.obj;
            //2.获取数据
            Basic basic = word.getBasic();
            String explains = null;
            explains = basic.getStrings(basic.getExplains());
            //3.在界面显示
            textView.setText(explains);
        }
    };
    /**
     * 界面创建
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_english);

        editText = findViewById(R.id.et);
        textView = findViewById(R.id.tv);
        mBtspeech = findViewById(R.id.b_speech);
        mIvLearningActivityBack = findViewById(R.id.iv_mainactivity_back);

        SpeechUtility.createUtility(this, "appid=" + "5e8c6381");
        tts = new TextToSpeech(this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if (status == TextToSpeech.SUCCESS) {
                    int result = tts.setLanguage(Locale.ENGLISH);
                    if (result == TextToSpeech.LANG_MISSING_DATA
                            || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                        Log.e("languageTag", "not use");
                    } else {
                        tts.speak("歪比歪比", TextToSpeech.QUEUE_FLUSH,
                                null);
                    }
                }
            }
        });
        //设置监听
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override
            public void onStart(String utteranceId) {
            }
            @Override
            public void onDone(String utteranceId) {
                tts.shutdown();//记得关闭
            }
            @Override
            public void onError(String utteranceId) {
            }
        });
        //设置按钮的点击事件播放EditText中的值
        mBtspeech.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tts.speak(editText.getText().toString(), TextToSpeech.QUEUE_FLUSH,
                        null);
            }
        });
        mIvLearningActivityBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EnglishActivity.this, LearningActivity.class);
                startActivity(intent);
                finish();
            }
        });
    }
/**
     * 查询按钮的监听方法
     * @param view
     */
    public void query(View view){
        String word = editText.getText().toString();
        //调用上网查词方法
        queryWord(word);
    }

    /**
     * 3.实现上网查词
     1.创建OkClient和Request对象
     2.创建Call对象
     3.重写Call对象的enCall方法
     1.获取响应数据
     2.封装成json对象
     3.转为java对象
     4.发送message给handler
     * @param s 要查询的单词
     */
    public void queryWord(String s){
        String url = "https://fanyi.youdao.com/openapi.do?keyfrom=youdianbao&key=1661829537&type=data&doctype=json&version=1.1&q="+s;
        //1.创建OkClient和Request对象
        OkHttpClient okHttpClient = new OkHttpClient();
        final Request request = new Request.Builder()
                .url(url)
                .get()
                .build();

        //2.创建Call对象
        okhttp3.Call call = okHttpClient.newCall(request);
        //3.重写Call对象的enqueue方法
        call.enqueue(new Callback() {
            @Override
            public void onFailure(okhttp3.Call call, IOException e) {
                Log.d(TAG, "onFailure: ");
            }
            @Override
            public void onResponse(okhttp3.Call call, Response response) throws IOException {
                //1.获取响应数据
                assert response.body() != null;
                String str = response.body().string();
                Log.d(TAG, "onResponse: " + str);
                try {
                    //2.封装成json对象
                    JSONObject jsonObject = new JSONObject(str);
                    //3.转为java对象
                    Word word = (Word) JsonUitl.stringToObject(jsonObject.toString(),Word.class);
                    //4.创建message,包裹信息
                    Message message = new Message();
                    message.obj = word;
                    //5.发送message给handler
                    handler.sendMessage(message);
                } catch (JSONException e) {
                    e.printStackTrace();
                }

            }
        });

    }
}