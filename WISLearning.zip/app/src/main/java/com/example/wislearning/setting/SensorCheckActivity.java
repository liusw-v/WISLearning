package com.example.wislearning.setting;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.wislearning.R;
import com.example.wislearning.maintain.MaintainActivity;


public class SensorCheckActivity<button> extends AppCompatActivity {
    private View mBtBack;
    private EditText etsensor;
    private View btnsensorcheck;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actiivity_weihumode);
        mBtBack = findViewById(R.id.bt_backtomaintain);//返回检测主界面
        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SensorCheckActivity.this, MaintainActivity.class);
                startActivity(intent);
            }
        });


        btnsensorcheck = findViewById(R.id.btn_motorcheck);

        btnsensorcheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etsensor = findViewById(R.id.et_motor);
                String strcode = etsensor.getText().toString();
                int code =  Integer.parseInt(strcode);
                String output;
                if(code == 4321)
                {
                    output = "传感器正常工作";
                }
                else{
                    output="传感器工作异常，请检查";
                }


                Toast.makeText(SensorCheckActivity.this,output, Toast.LENGTH_SHORT).show();
            }
        });


    }
}
