package com.example.wislearning.setting;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.wislearning.R;

public class AboutUsActivity extends AppCompatActivity {

    private Button mBtBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_us);
        mBtBack = findViewById(R.id.bt_backtosetting1);
        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AboutUsActivity.this, SettingActivity.class);
                startActivity(intent);
            }
        });
    }
}
