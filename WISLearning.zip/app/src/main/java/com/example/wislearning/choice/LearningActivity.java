package com.example.wislearning.choice;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Build;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;

import com.example.wislearning.MainActivity;
import com.example.wislearning.R;
import com.example.wislearning.choice.english.EnglishActivity;
import com.example.wislearning.choice.examcase.activity.TextMainActivity;
import com.example.wislearning.choice.math.EasyActivity;
import com.example.wislearning.choice.math.MathActivity;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LearningActivity extends AppCompatActivity {

    private Button mBtMath;
    private Button mBtEnglish;
    private Button mBtEasy;
    private Button mBtBack;
    private Button mBtTest;

    private Button mBtmathmp4;
    private Button mBtenglishmp4;
    private Button mBteasymp4;
    private Button mBttestmp4;

    private SoundPool sp ;//声明一个SoundPool
    private Map<Integer, Integer> soundmap = new HashMap<Integer, Integer>();

    private int mathmp4;//定义一个整型用load（）；来设置suondID
    private int englishmp4;
    private int easymp4;
    private int testmp4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_learning);
        mBtMath = findViewById(R.id.bt_math);//计算器
        mBtEnglish = findViewById(R.id.bt_english);//单词
        mBtEasy = findViewById(R.id.bt_easy);//口算
        mBtBack = findViewById(R.id.bt_backtohome);
        mBtTest = findViewById(R.id.bt_test);//趣味小测试
        mBtmathmp4 = findViewById(R.id.bt_mathmp4);
        mBtenglishmp4 = findViewById(R.id.bt_englishmp4);
        mBteasymp4 = findViewById(R.id.bt_easymp4);
        mBttestmp4 = findViewById(R.id.bt_testmp4);

        setListeners();
        init();//初始化声音池

    }

    private void init() {//初始化声音池
        // TODO Auto-generated method stub
        sp= new SoundPool(1, AudioManager.STREAM_SYSTEM, 5);//第一个参数为同时播放数据流的最大个数，第二数据流类型，第三为声音质量
        mathmp4 = sp.load(this, R.raw.calculation, 1); //把你的声音素材放到res/raw里，第2个参数即为资源文件，第3个为音乐的优先级
        englishmp4 = sp.load(this, R.raw.word, 1);
        easymp4 = sp.load(this, R.raw.exercise30, 1);
        testmp4 = sp.load(this, R.raw.test, 1);
    }

    private void setListeners(){
        Onclick onclick = new Onclick();
        mBtEnglish.setOnClickListener(onclick);
        mBtMath.setOnClickListener(onclick);
        mBtEasy.setOnClickListener(onclick);
        mBtBack.setOnClickListener(onclick);
        mBtTest.setOnClickListener(onclick);
        mBtmathmp4.setOnClickListener(listener);
        mBtenglishmp4.setOnClickListener(listener);
        mBteasymp4.setOnClickListener(listener);
        mBttestmp4.setOnClickListener(listener);
    }
    private View.OnClickListener listener =new View.OnClickListener(){
        @Override
        public void onClick(View arg0) {
            switch (arg0.getId()){
                case R.id.bt_mathmp4:
                    // TODO Auto-generated method stub
                    sp.play(mathmp4, 1, 1, 0, 0, 1);
                    break;
                case R.id.bt_englishmp4:
                    sp.play(englishmp4, 1, 1, 0, 0, 1);
                    break;
                case R.id.bt_easymp4:
                    sp.play(easymp4, 1, 1, 0, 0, 1);
                    break;
                case R.id.bt_testmp4:
                    sp.play(testmp4, 1, 1, 0, 0, 1);
                    break;
            }
        }
    };

    @Override
    protected void onDestroy() {
        sp.release();//回收soundpool资源
        super.onDestroy();
    }


    private class Onclick implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()){
                case R.id.bt_backtohome:
                    intent = new Intent(LearningActivity.this, MainActivity.class);
                    break;
                case R.id.bt_math:
                    intent = new Intent(LearningActivity.this,MathActivity.class);
                    break;
                case R.id.bt_english:
                    intent = new Intent(LearningActivity.this, EnglishActivity.class);
                    break;
                case R.id.bt_easy:
                    intent = new Intent(LearningActivity.this, EasyActivity.class);
                    break;
                case R.id.bt_test:
                    intent = new Intent(LearningActivity.this, TextMainActivity.class);
                    break;
            }
            startActivity(intent);
            finish();
        }
    }
}