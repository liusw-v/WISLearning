package com.example.wislearning.choice.examcase.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.wislearning.R;
import com.example.wislearning.choice.LearningActivity;

public class TextMainActivity extends AppCompatActivity {

	private Button mBtStartExam;
	private Button mBtBack;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_text_main);

		mBtStartExam =  findViewById(R.id.bt_main_start_test);
		mBtBack = findViewById(R.id.bt_text_back);
		mBtStartExam.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(TextMainActivity.this,ExamActivity.class);
				startActivity(intent);
			}
		});
		mBtBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(TextMainActivity.this, LearningActivity.class);
				startActivity(intent);
				finish();
			}
		});

	}

	@Override
	public void onBackPressed() {
		finish();
	}
}
