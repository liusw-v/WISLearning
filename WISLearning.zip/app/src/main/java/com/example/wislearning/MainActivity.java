package com.example.wislearning;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.Button;

import com.example.justloginregistertest.LoginActivity;
import com.example.wislearning.choice.LearningActivity;
import com.example.wislearning.setting.SettingActivity;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    //private TextView mTvWelcome;
    private Button mBtLearning;
    private Button mBtSetting;
    private Button mBtMainLogout;
    private Button mBtstartmp4;

    private SoundPool sp;//声明一个SoundPool
    private int music;//定义一个整型用load（）；来设置suondID

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mBtLearning = findViewById(R.id.bt_learning);
        mBtSetting = findViewById(R.id.bt_setting);
        mBtMainLogout = findViewById(R.id.bt_main_logout);
        mBtstartmp4 = findViewById(R.id.bt_startmp4);

        initView();
        init();//初始化声音池的方法
    }


    private void init() {//初始化声音池
        // TODO Auto-generated method stub
        sp= new SoundPool(10, AudioManager.STREAM_SYSTEM, 5);//第一个参数为同时播放数据流的最大个数，第二数据流类型，第三为声音质量
        music = sp.load(this, R.raw.start, 1); //把你的声音素材放到res/raw里，第2个参数即为资源文件，第3个为音乐的优先级
    }


    private void initView() {
        // 绑定点击监听器
        mBtMainLogout.setOnClickListener(this);
        mBtLearning.setOnClickListener(this);
        mBtSetting.setOnClickListener(this);
        mBtstartmp4.setOnClickListener(listener);
    }

    @Override
    public void onClick(View v) {
        Intent intent = null;
        switch (v.getId()){
            case R.id.bt_main_logout:
                intent = new Intent(MainActivity.this, LoginActivity.class);
                break;
            case R.id.bt_learning:
                intent = new Intent(MainActivity.this, LearningActivity.class);
                break;
            case R.id.bt_setting:
                intent = new Intent(MainActivity.this, SettingActivity.class);
                break;
        }
        startActivity(intent);
    }
    private View.OnClickListener listener =new View.OnClickListener(){
        @Override
        public void onClick(View arg0) {
            // TODO Auto-generated method stub
            sp.play(music, 1, 1, 0, 0, 1);
        }
    };
    @Override
    protected void onDestroy() {
        sp.release();//回收soundpool资源
        super.onDestroy();
    }
}
