package com.example.wislearning.maintain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.wislearning.MainActivity;
import com.example.wislearning.R;
import com.example.wislearning.setting.MotorCheckActivity;
import com.example.wislearning.setting.SensorCheckActivity;
import com.example.wislearning.setting.SettingActivity;

public class MaintainActivity extends AppCompatActivity {

    private Button mBtExitMaintain;
    private Button mBtReadSensor;
    private Button mBtServo;
    private Button mBtBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maintain);
        mBtExitMaintain = findViewById(R.id.bt_exitmaintain);
        mBtReadSensor = findViewById(R.id.bt_readsensor);
        mBtServo = findViewById(R.id.bt_servo);
        mBtBack = findViewById(R.id.bt_backtosetting3);
        setListeners();
    }


    private void setListeners(){
        Onclick onclick = new Onclick();
        mBtExitMaintain.setOnClickListener(onclick);
        mBtReadSensor.setOnClickListener(onclick);
        mBtServo.setOnClickListener(onclick);
        mBtBack.setOnClickListener(onclick);
    }

    private class Onclick implements View.OnClickListener{
        @Override
        public void onClick(View v) {
            Intent intent = null;
            switch (v.getId()){
                case R.id.bt_backtosetting3:
                case R.id.bt_exitmaintain:
                    intent = new Intent(MaintainActivity.this, SettingActivity.class);
                    break;
                case R.id.bt_readsensor:
                    intent = new Intent(MaintainActivity.this, SensorCheckActivity.class);
                    break;
                case R.id.bt_servo:
                    intent = new Intent(MaintainActivity.this, MotorCheckActivity.class);
                    break;
            }
            startActivity(intent);
        }
    }

}
