package com.example.wislearning.choice.math;

import java.util.Random;

public class function {
    public  long Former=0;
    public  long Latter=0;
    public long getRandom(int num){
        int NUM=num;
        Random random=new Random();
        int number=random.nextInt(NUM)+1;
        return number;
    }
    public long setPlus(long former,long latter){
        return former+latter;
    }
    public long setMinus(long former,long latter){
        long result=0;
        boolean Flag=true;
        do {
            if (former>latter)
            {
                Former=former;
                Latter=latter;
                Flag=false;
            }
            else
            if (former<latter)
            {
                Former=latter;
                Latter=former;
                Flag=false;
            }
            else {
                Former=getRandom(100);
                Latter=getRandom(100);
                Flag=true;
            }


        }while (Flag);
        result=Former-Latter;
        return result;
    }
    public long setMutiply(long former,long latter){
        return former*latter;
    }
    public long setDivide(long former,long latter)
    {
        long result=0;
        boolean FLAG=true;
        do{

            if (former%latter==0)
            {
                result=former/latter;
                FLAG=false;
            }
            else{
                Former=getRandom(100)+1;
                Latter=getRandom(19)+1;
                former=Former;
                latter=Latter;
                result=Former/Latter;
                System.out.println("============"+Former+"==========="+Latter+"===================");
            }

        }while (FLAG);
        return result;
    }
}
