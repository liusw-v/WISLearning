package com.example.wislearning.choice.examcase.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.wislearning.R;
import com.example.wislearning.choice.examcase.model.Examination;


/**
 * 涉及内容：
 * <p>
 * <p>
 * 逻辑分析：
 * 问题，选项，知道用户是否选择了正确的选项，并把值保存，传递给ResultActivity，
 * 点击上一个、下一个 可以正确的反馈
 * <p>
 * 遇到的问题：
 * 问题数组到最后一个时，直接跳转到下一个Activity，最后一道题没有显示。  在点击事件中设置currentIndex的改变，而不是在updateQuestion()中
 * 由于用到的是同一个布局，所以在下一题会重复得到上一题的选项，默认选择， clearCheck
 * 结果页面点击返回按钮，直接返回首页，而不是测试页面。
 * <p>
 * 记录选择状态，必须用一个集合或者数组，Intent传值无法传集合，用数组实现
 * 记录选择状态的事件，用数组记录，数组无法动态添加数据，只能一个一个被赋值，无法确定赋值的时间
 */
public class ExamActivity extends AppCompatActivity implements View.OnClickListener {

    private static final String TAG = "ExamActivity";
    private static final String KEY_INDEX = "index";
    private static final int REQUEST_CODE_RESULT = 0;

    private TextView tvQue;
    private RadioGroup rgOption;
    private RadioButton rbOption1, rbOption2, rbOption3, rbOption4;
    private TextView tvPre;
    private TextView tvNext;
    private TextView tvAnswer;
    private String answer;
    private Button mBtBackToResult;

    private Examination[] questionArr = new Examination[]{
            new Examination("1.\tsee：They saw it.", "A.\t切", "B.\t等待", "C.\t看", "D.\t开始", "C"),
            new Examination("2.\ttime：They have a lot of time.", "A.\t钱", "B.\t食物", "C.\t时间", "D.\t朋友", "C"),
            new Examination("3.\tperiod：It was a difficult period.", "A.\t问题", "B.\t时期", "C.\t要做的事", "D.\t书", "B"),
            new Examination("4.\tfigure：Is this the right figure？", "A.\t号码", "B.\t答案", "C.\t地方", "D.\t时间", "A"),
            new Examination("5.\tpoor：We are poor.", "A.\t贫穷的", "B.\t感到幸福的", "C.\t很感兴趣的", "D.\t不喜欢努力工作的", "A"),
            new Examination("6.\tdrive：He drives fast.", "A.\t游泳", "B.\t学习", "C.\t扔球", "D.\t开车", "D"),
            new Examination("7.\tjump：She tried to jump.", "A.\t漂浮", "B.\t跳", "C.\t停车", "D.\t跑", "B"),
            new Examination("8.\tshoe：Where is your shoe?", "A.\t爸爸或妈妈", "B.\t钱包", "C.\t钢笔", "D.\t鞋子", "D"),
            new Examination("9.\tstandard: Her standards are very high.", "A.\t后跟", "B.\t分数", "C.\t要价", "D.\t标准", "D"),
            new Examination("10.\tbasis: I don’t understand the basis.", "A.\t原因", "B.\t话", "C.\t路标", "D.\t中心议题", "A"),
            new Examination("11.\tmaintain: Can they maintain it?", "A.\t维持", "B.\t扩大", "C.\t改善", "D.\t得到", "A"),
            new Examination("12.\tstone: He sat on a stone.", "A.\t石头", "B.\t凳子", "C.\t垫子", "D.\t树枝", "A"),
            new Examination("13.\tupset: I am upset.", "A.\t疲倦的", "B.\t著名的", "C.\t富足的", "D.\t不高兴的", "D"),
            new Examination("14.\tdrawer: The drawer was empty.", "A.\t抽屉", "B.\t车库", "C.\t冰箱", "D.\t鸟笼", "A"),
            new Examination("15.\tpatience: He has no patience.", "A.\t耐心", "B.\t很忙", "C.\t信心", "D.\t公正", "A"),
            new Examination("16.\tnil: His mark for that question was nil.", "A.\t很差的", "B.\t什么也没有的", "C.\t很好的", "D.\t中等的", "B"),
            new Examination("17.\tpub: They went to the pub.", "A.\t酒吧", "B.\t银行", "C.\t商场", "D.\t游泳池", "A"),
            new Examination("18.\tcircle: Make a circle.", "A.\t素描", "B.\t空白", "C.\t圆圈", "D.\t大洞", "C"),
            new Examination("19.\tmicrophone: Please use the microphone.", "A.\t微波炉", "B.\t麦克风", "C.\t显微镜", "D.\t直升机", "B"),
            new Examination("20.\tpro: He’s a pro.", "A.\t间谍", "B.\t傻瓜", "C.\t记者", "D.\t职业运动员", "D"),
    };

    private String[] explain = {
            "\n" +
                    "v.\t看见; 见到; 看出; 看得见; 看; 有视力; 观看(比赛、电视节目、演出等); \n" +
                    "n.\t" + "主教(或大主教)教区; 主教(或大主教)权限; 牧座; ",
            "\n" +
                    "n.\t(以分钟、小时、天等计量的) 时间; (钟表所显示的) 时间，钟点，时刻; (世界某一地区所计量的) 时，时间; \n" +
                    "v.\t" + "为…安排时间; 选择…的时机; 计时; 测定…所需的时间; 在某一时刻击球(或踢球); \n" +
                    "[例句]\n" +
                    "Time passed, and still Ma did not appear\n" +
                    "时间一点点过去，马先生仍然没有出现。",
            "\n" +
                    "n.\t一段时间; 时期; (人生或国家历史的) 阶段，时代; 纪(地质年代，代下分纪); \n" +
                    "adv.\t" + "某一时代的; \n" +
                    "adj.\t" + "具有某个时代特征的; ",
            "\n" +
                    "n.\t(代表数量，尤指官方资料中的) 数字; 数字符号; 字码; 位数; 算术; \n" +
                    "v.\t" + "是重要部分; 是…的部分; 认为，认定(某事将发生或属实); 计算(数量或成本); \n" +
                    "[例句]\n" +
                    "It would be very nice if we had a true figure of how many people in this country haven't got a job\n" +
                    "如果我们能得到该国失业人口的真实数字就好了。",
            "\n" +
                    "adj.\t贫穷的; 贫寒的; 清贫的; 贫困者; 穷人; 可怜的; 不幸的; 令人同情的; \n" +
                    "[例句]\n" +
                    "The reason our schools cannot afford better teachers is because people here are poor\n" +
                    "我们的学校请不起好老师的原因是因为这里的人穷。",
            "\n" +
                    "v.\t驾驶; 开车; 驾车送(人); 拥有(或驾驶)…汽车; \n" +
                    "n.\t" + "驱车旅行; 驾车路程; 传动(或驱动)装置; (从街道通向住宅的宽阔或私人的) 车道; \n" +
                    "[例句]\n" +
                    "I drove into town and went to a restaurant for dinner\n" +
                    "我驱车到市里一家餐馆就餐。",
            "v.\n" +
                    "v.\t跳; 跃; 跳跃; 跳过; 跃过; 跨越; 快速移动; 突然移动; \n" +
                    "n.\t" + "跳; 跃; 跳跃; (比赛中需跳过的) 障碍物; 突升; 猛涨; 激增; \n" +
                    "[例句]\n" +
                    "I jumped over the fence\n" +
                    "我跳过了栅栏。",
            "\n" +
                    "n.\t鞋; \n" +
                    "v.\t" + "给(马)钉蹄铁; \n" +
                    "[例句]\n" +
                    "Low-heeled comfortable shoes are best\n" +
                    "舒服的低跟鞋子最好了。",
            "\n" +
                    "n.\t(品质的) 标准，水平，规格，规范; 正常的水平; 应达到的标准; 行为标准; 道德水准; \n" +
                    "adj.\t" + "普通的; 正常的; 通常的; 标准的; (符合) 标准的; 按一定规格制作的; 权威性的; \n" +
                    "[例句]\n" +
                    "The standard of professional cricket has never been lower\n" +
                    "职业板球的水平从来没有这么低过。",
            "\n" +
                    "n.\t原因; 缘由; 基准; 准则; 方式; 基础; 要素; 基点; \n" +
                    "[例句]\n" +
                    "We're going to be meeting there on a regular basis\n" +
                    "我们将定期在那里会面。",
            "\n" +
                    "v.\t跳; 跃; 跳跃; 跳过; 跃过; 跨越; 快速移动; 突然移动; \n" +
                    "n.\t" + "跳; 跃; 跳跃; (比赛中需跳过的) 障碍物; 突升; 猛涨; 激增; \n" +
                    "[例句]\n" +
                    "I jumped over the fence\n" + "我跳过了栅栏。",
            "\n" +
                    "n.\t石头; 石料; 岩石; 石块; 石子; (加工成某形状为某用途的) 石块; \n" +
                    "v.\t" + "向…扔石块; 用石头砸; 去掉…的果核; ",
            "\n" +
                    "v.\t使烦恼; 使心烦意乱; 使生气; 打乱; 搅乱; 使(肠胃)不适; \n" +
                    "adj.\t" + "难过; 不高兴; 失望; 沮丧; 肠胃不适; 腹泻; \n" +
                    "n.\t" + "(意外的) 混乱，困扰，麻烦; 意外的结果; 爆冷门; 肠胃病; 腹泻; ",
            "\n" +
                    "n.\t抽屉; 开票人; 出票人; ",
            "\n" +
                    "n.\t耐心; 忍耐力; 毅力; 坚忍; 恒心; 单人纸牌游戏; ",
            "\n" +
                    "n.\t(数码) 零; (体育比赛中的) 0分; 无; 零; ",
            "\n" +
                    "n.\t酒吧; 酒馆; ",
            "\n" +
                    "n.\t圆; 圆形; 圆周; 圆圈; 圆形物; 环状物; 圈; 环; \n" +
                    "v.\t" + "(尤指在空中) 盘旋，环行，转圈; 围绕…画圈; 圈出; 圈起; ",
            "\n" +
                    "n.\t麦克风; 话筒; 传声器;",
            "\n" +
                    "n.\t"+"从事某职业的人; 职业运动员; 职业选手; 老手; \n" +
                    "adj.\t" + "职业的; 专业的; \n" +
                    "prep.\t" + "赞成; 支持;",
    };

    private int currentIndex = 0;
    private boolean flag;
    private boolean[] flagArr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_text_exam);

        mBtBackToResult = findViewById(R.id.bt_back_to_resource);


        // 取出销毁状态前 保存的数据
        if (savedInstanceState != null) {
            currentIndex = savedInstanceState.getInt(KEY_INDEX, 0);
        }

        initView();
        updateQuestion();

    }

    //保存销毁前的状态
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        Log.d(KEY_INDEX, "onSaveInstanceState");
        outState.putInt(KEY_INDEX, currentIndex);
    }

    private void initView() {

        Button mBtExit = findViewById(R.id.bt_Examctivity_back);
        mBtExit.setOnClickListener(this);

        tvQue = findViewById(R.id.tv_exam_question);
        tvQue.setOnClickListener(this);

        rgOption = findViewById(R.id.rg_exam_choose);
        rbOption1 = findViewById(R.id.rb_exam_choose1);
        rbOption2 = findViewById(R.id.rb_exam_choose2);
        rbOption3 = findViewById(R.id.rb_exam_choose3);
        rbOption4 = findViewById(R.id.rb_exam_choose4);

        answer = questionArr[currentIndex].getAnswer();

        flagArr = new boolean[questionArr.length];

        rgOption.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                // RadioGroup的监听
                switch (checkedId) {
                    case R.id.rb_exam_choose1:
                        if (answer.equals("A")) {
                            flag = true;
                        }
                        break;
                    case R.id.rb_exam_choose2:
                        if (answer.equals("B")) {
                            flag = true;
                        }
                        break;
                    case R.id.rb_exam_choose3:
                        if (answer.equals("C")) {
                            flag = true;
                        }
                        break;
                    case R.id.rb_exam_choose4:
                        if (answer.equals("D")) {
                            flag = true;
                        }
                        break;
                }
            }
        });


        tvPre = findViewById(R.id.tv_exam_previous);
        tvPre.setOnClickListener(this);

        tvNext = findViewById(R.id.tv_exam_next);
        tvNext.setOnClickListener(this);

        tvAnswer = findViewById(R.id.tv_exam_answer);
        tvAnswer.setText(answer);

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.bt_Examctivity_back:
                if (tvAnswer.getVisibility() == View.GONE) {
                    AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                            .setTitle("确定要退出测试吗")
                            .setPositiveButton("确定退出", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            }).setNegativeButton("继续测试", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    dialog.create().show();
                }else {
                    // todo 查看过答案后直接返回应用首页
                    finish();
                }

                break;

            case R.id.tv_exam_question:

                // 为数组中元素赋值
                flagArr[currentIndex] = flag;
                Log.e("ExamActivity", flagArr[currentIndex] + "");

                if (currentIndex == questionArr.length - 1) {
                    Intent intent = new Intent(ExamActivity.this, ResultActivity.class);
                    intent.putExtra("totalNum", questionArr.length);
//					intent.putExtra("flag",flag);// 答案是否正确,,,这样仅仅传递过去 最后一个值得状态，所以应该传一个数组
                    intent.putExtra("flag", flagArr);
                    startActivityForResult(intent, REQUEST_CODE_RESULT);
                } else {
                    currentIndex++;
                    updateQuestion();
                }
                break;

            case R.id.tv_exam_next:
                // 为数组中元素赋值
                flagArr[currentIndex] = flag;
                Log.e("ExamActivity", flagArr[currentIndex] + "num" + currentIndex);

                if (currentIndex == questionArr.length - 1) {
                    Intent intent = new Intent(ExamActivity.this, ResultActivity.class);
                    intent.putExtra("totalNum", questionArr.length);
                    intent.putExtra("flag", flagArr);
                    startActivityForResult(intent, REQUEST_CODE_RESULT);
                } else {
                    currentIndex++;
                    answer = questionArr[currentIndex].getAnswer();
                    updateQuestion();
                }
                break;

            case R.id.tv_exam_previous:
                // 为数组中元素赋值
                flagArr[currentIndex] = flag;
                Log.e("ExamActivity", flagArr[currentIndex] + "");

                currentIndex--;
                answer = questionArr[currentIndex].getAnswer();

                updateQuestion();
                break;

            default:
                break;
        }
    }

    private void updateQuestion() {

        Log.d(TAG, "Updating question text for question and option#" + currentIndex, new Exception());
        String question = questionArr[currentIndex].getQuestion();
        tvQue.setText(question);
        String option1 = questionArr[currentIndex].getOption1();
        rbOption1.setText(option1);
        String option2 = questionArr[currentIndex].getOption2();
        rbOption2.setText(option2);
        String option3 = questionArr[currentIndex].getOption3();
        rbOption3.setText(option3);
        String option4 = questionArr[currentIndex].getOption4();
        rbOption4.setText(option4);

        rgOption.clearCheck(); // 清除选中状态
        flag = false;

        mBtBackToResult.setVisibility(View.GONE);
        tvAnswer.setVisibility(View.GONE);
        tvAnswer.setText(getString(R.string.answer) + questionArr[currentIndex].getAnswer() + explain[currentIndex]);

        if (currentIndex == 0) {
            tvPre.setText(R.string.no);
            tvPre.setEnabled(false);
        } else {
            tvPre.setText(R.string.previous);
            tvPre.setEnabled(true);
        }

        if (currentIndex == questionArr.length -1){
            tvNext.setText(R.string.done);
        }
        tvNext.setText(R.string.next);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            currentIndex = data.getIntExtra("position", 0);
            answer = questionArr[currentIndex].getAnswer();
            updateQuestion();
        }
        if (requestCode == REQUEST_CODE_RESULT) {

            mBtBackToResult.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ExamActivity.this, ResultActivity.class);
                    intent.putExtra("totalNum", questionArr.length);
                    intent.putExtra("flag", flagArr);
                    startActivityForResult(intent, REQUEST_CODE_RESULT);
                }
            });
            tvAnswer.setVisibility(View.VISIBLE);
            mBtBackToResult.setVisibility(View.VISIBLE);
            mBtBackToResult.setText(R.string.back_to_result);
            tvNext.setVisibility(View.GONE);
            tvPre.setVisibility(View.GONE);


        }

    }

    @Override
    public void onBackPressed() {
        if (tvAnswer.getVisibility() == View.GONE) {
            AlertDialog.Builder dialog = new AlertDialog.Builder(this)
                    .setTitle("确定要退出测试吗")
                    .setPositiveButton("确定退出", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            finish();
                        }
                    }).setNegativeButton("继续测试", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    });
            dialog.create().show();
        } else {
            finish();
        }
    }
}
