package com.example.wislearning.choice.english;

/**
 * Created by Administrator on 2019/7/25.
 */

public class Word {
    Basic basic;

    public Basic getBasic() {
        return basic;
    }
}
