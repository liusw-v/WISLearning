package com.example.wislearning.choice.math;


import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.wislearning.choice.LearningActivity;
import com.example.wislearning.R;

import java.util.ArrayList;
import java.util.Random;

public class EasyActivity extends AppCompatActivity {
    private long former=0;
    private long latter=0;
    private long result=0;
    private long count=1;
    private long RIGHT=0;
    private float percentage=0;

    ArrayList<String> arrayList=new ArrayList<String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_easy);

        final EditText editText= findViewById(R.id.INPUTTEXT);
        Button next= findViewById(R.id.next);
        Button homepage= findViewById(R.id.homepage);
        Button submit= findViewById(R.id.submit);
        final TextView textview= findViewById(R.id.textView2);
        final TextView countnum= findViewById(R.id.countnum);
        final Button back2home= findViewById(R.id.backtohome);

        setquestion();
        back2home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent back=new Intent(EasyActivity.this, LearningActivity.class);
                startActivity(back);
                finish();
            }
        });

        homepage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                StringBuffer partinfo=new StringBuffer("");
                for (int i = 0; i <arrayList.size() ; i++) {
                    String info=  arrayList.get(i);
                    partinfo.append(info+"\n");
                }

                String allinfo=partinfo.toString();
                textview.setText(allinfo);
            }
        });
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getnum = editText.getText().toString();
                int GETNUM = Integer.valueOf(getnum);
                if (GETNUM == result) {
                    Toast.makeText(EasyActivity.this, "回答正确~", Toast.LENGTH_SHORT).show();
                    RIGHT++;
                } else {
                    Toast.makeText(EasyActivity.this,"做错了呢~请再细心计算一遍",Toast.LENGTH_SHORT).show();
                }

            }
        });
        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                editText.setText("");
                countnum.setText("已经做了"+count+"/30道题,做对"+RIGHT+"道");
                count++;

                if (count>30) {
                    count=30;
                    new AlertDialog.Builder(EasyActivity.this).setMessage("今天的任务完成啦！"
                    ).setPositiveButton("查看今天的所有题目", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            StringBuffer partinfo=new StringBuffer("");
                            for (int i = 0; i <arrayList.size() ; i++) {
                                String info=  arrayList.get(i);
                                partinfo.append(info+"\n");
                            }
                            textview.setText(partinfo);
                        }
                    }).setNegativeButton("再来三十道！", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            count=1;
                            countnum.setText("");
                            setquestion();
                            textview.setText("");
                        }
                    }).create().show();
                }
                else
                    result=setquestion();
            }
        });

    }
    public long setquestion(){
        TextView textView= (TextView) findViewById(R.id.textView);
        function myfunc=new function();
        former=myfunc.getRandom(100)+1;
        latter=myfunc.getRandom(100)+1;
        Random random=new Random();
        int CHOOSENUM=random.nextInt(3);
        switch (CHOOSENUM)
        {
            case 0:{result=myfunc.setPlus(former,latter);
                textView.setText(former + "+" + latter+"=");
                String text=former + "+" + latter+"="+result;
                arrayList.add(text);
            }
            break;
            case 1:{result=myfunc.setDivide(former,latter);
                textView.setText(myfunc.Former + "÷" + myfunc.Latter+"=");
                String text=myfunc.Former + "÷" + myfunc.Latter+"="+result;
                arrayList.add(text);
            }
            break;
            case 2:{
                result=myfunc.setMinus(former,latter);
                textView.setText(myfunc.Former + "-" + myfunc.Latter+"=");
                String text=myfunc.Former + "-" + myfunc.Latter+"="+result;
                arrayList.add(text);
            }
            break;
            case 3:{
                result=myfunc.setMutiply(former,latter);
                textView.setText(myfunc.Former + "×" + myfunc.Latter+"=");
                String text=myfunc.Former + "×" + myfunc.Latter+"="+result;
                arrayList.add(text);
            }
            break;
        }
        return result;

    }
}