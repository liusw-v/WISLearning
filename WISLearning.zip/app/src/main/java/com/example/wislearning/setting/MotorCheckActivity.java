package com.example.wislearning.setting;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import com.example.wislearning.R;
import com.example.wislearning.maintain.MaintainActivity;


public class MotorCheckActivity<button> extends AppCompatActivity {
    private View mBtBack;
    private TextView tvmotorck;
    private EditText etmotor;
    private View btnmotorcheck;
    private EditText etmotor2;


    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.actiivity_weihumode);
        mBtBack = findViewById(R.id.bt_backtomaintain);//返回检测主界面
        mBtBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MotorCheckActivity.this, MaintainActivity.class);
                startActivity(intent);
            }
        });


        btnmotorcheck = findViewById(R.id.btn_motorcheck);

        btnmotorcheck.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                etmotor = findViewById(R.id.et_motor);
                String strcode = etmotor.getText().toString();
                int code =  Integer.parseInt(strcode);
                String output;
                if(code == 1234)
                {
                 output = "伺服电机正常运转";
                }
                else{
                     output="伺服电机运转异常，请检查";
                }


                Toast.makeText(MotorCheckActivity.this,output, Toast.LENGTH_SHORT).show();
            }
        });


    }
}
